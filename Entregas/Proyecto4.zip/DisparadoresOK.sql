INSERT INTO calificaciones (comentario, valoracion, clientes_id, perfiles_id)
    VALUES ('Comentario seis', 4, 5, 4);

INSERT INTO firmas 
    VALUES('860000643-8', 'Lloreda S A S',
            '6016065611', NULL, 1);

INSERT INTO abogados
    VALUES ('8437983344', NULL, '3369550678',
            'Harri Lane', '06/02/1989', 3, NULL);

INSERT INTO solicitudes (descripcion, clientes_id, abogados_nuip)
    VALUES ('Descripcion seis', '10/01/2022', 6, '8437980011');
    
INSERT INTO perfiles (descripcion, a�os_experiencia, tarifa_minima, calificacion_promedio, abogados_nuip)
    VALUES ('Descripcion perfil seis', 14, 900000, NULL, '8437980011');

INSERT INTO lugares (departamento, municipio, direccion)
    VALUES ('Atl�ntico', 'Barranquilla', NULL);
    
INSERT INTO areas (nombre, descripcion)
    VALUES ('Derecho Mercantil', 'Descripcion area');

INSERT INTO estudios (titulo, universidad, fecha_inicio, fecha_final, perfiles_id)
    VALUES ('Environmental Specialist', 'Universidade Fernando Pessoa',
            '13/09/2015', '11/03/2019', 1);

INSERT INTO asesorias (descripcion, fecha, duaracion, precio, abogados_nuip, clientes_id)
    VALUES ('Descripcion seis', '19/06/2019', 120, 500000, '1968720863', 2);

        
INSERT INTO contratos (fecha_firma, descripcion, forma_pago, remuneracion, clientes_id, abogados_nuip, lugares_id)
    VALUES ('09/10/2020', 'Descripcion seis', 'Forma seis', 1000000,
            2, '8437980011', 1);

INSERT INTO clientes (nombre, correo, telefono, abogados_nuip)
    VALUES ('Abernathy Lockman', 'clientecinco@gmail.com', 
            '6927071632', '8437989988');
