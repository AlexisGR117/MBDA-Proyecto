DELETE FROM lugares WHERE id = 1;
UPDATE lugares SET id = 1 WHERE id = 2;

DELETE FROM revisiones WHERE perfiles_id = 2;
UPDATE revisiones SET perfiles_id = 1 WHERE clientes_id = 3;

UPDATE clientes SET nombre = 'Juan Carlos' WHERE id = 1;

DELETE FROM personasNaturales WHERE nuip = '6767303582';
UPDATE personasNaturales SET clientes_id = 1 WHERE nuip = '6767303582';

DELETE FROM personasJuridicas WHERE nit = '937708198-8';
UPDATE personasJuridicas SET nit = '937708198-9' WHERE nit = '937708198-8';

UPDATE firmas SET nit = '937708198-9' WHERE nit = '830022196-0';

UPDATE espFirmas SET firmas_nit = '937708198-9' WHERE areas_id = 1;

DELETE FROM areas WHERE id = 4;
UPDATE areas SET nombre = 'Derecho Familiar' WHERE id = 3;

UPDATE abogados SET fecha_nacimiento = '01/01/200' WHERE nuip = '2329664486';

