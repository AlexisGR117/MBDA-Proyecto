-- TCalificacion
-- Valoracion mayor a 5
INSERT INTO calificaciones
    VALUES(1006, NULL, 6, '08/04/2022', 1001, 1001);

-- TCorreo
-- Sin arroba
INSERT INTO firmas
    VALUES('782903512-6', 'correonombre.uno', '3206734490', 'correonombre.uno', 5);
-- Sin punto
INSERT INTO abogados
    VALUES('1003618876', 'correo@nombredos', '3184617625', 'nombre dos', 
           '12/12/1984', 13, '782903512-6');
-- Sin caracteres antes del arroba
INSERT INTO clientes 
    VALUES(1, 'nombre tres', '@nombre.tres', '3147335536', '1003618876');
-- Sin caracteres entre el arroba y el punto
INSERT INTO jueces
    VALUES('1003615431', 'nombre cuatro', 'correo@.cuatro', NULL);
-- Sin caracteres despues del punto
INSERT INTO juzgados
    VALUES(1, 'nombre cinco', 'FA', 'correo@nombre.', '3218530710', 2);

-- TDuracion
-- Duracion mayor a 240 minutos
INSERT INTO audiencias
    VALUES(1, '21/03/2021', 241, '1003615431', 1);

-- TEstado
-- Tipo de estado que no esta dentro de los establecidos
INSERT INTO casos
    VALUES(1, 'Finalizado', 'Ganado');

-- TJuzgado
-- Tipo de juzgado que no esta dentro de los establecidos
INSERT INTO juzgados
    VALUES(2, 'nombre seis', 'CA', 'correo@nombre.seis', '3137685430', 3);

-- TMoneda
-- precio menor que cero
INSERT INTO Asesorias
    VALUES(1, 'asesoria uno', '21/03/2021', 124, -1000000, '1003618876', 1);
    
--TNit
-- No cumpla con el formato del NIT
INSERT INTO personasJuridicas
    VALUES('7829035126', 'Razon social uno', 1);

-- TNombre
-- Nombre sin espacios
INSERT INTO jueces
    VALUES('1005984735', 'nombresiete', 'correo@numero.siete', '3156328762');
    
-- TNuip
-- NUIP con caracteres que no son digitos
INSERT INTO personasNaturales
    VALUES('100361886A', '17/01/2003', 1);
    
-- TPrueba
-- Tipo de prueba que no esta dentro de los establecidos
INSERT INTO pruebas
    VALUES(1, 'INS', 'Descripcion prueba uno', 'medio prueba', 1);

-- TResultado
-- Tipo de resultado que no esta dentro de los establecidos
INSERT INTO casos
    VALUES(2, 'Activo', 'Ga');

-- TTelefono
-- Telefono con caracteres que no son digitos
INSERT INTO jueces
    VALUES('1005984735', 'nombre ocho', 'correo@numero.ocho', '315632876A');
    
DELETE FROM lugares WHERE id = 1;
UPDATE lugares SET id = 1 WHERE id = 2;

DELETE FROM revisiones WHERE perfiles_id = 2;
UPDATE revisiones SET perfiles_id = 1 WHERE clientes_id = 3;

UPDATE clientes SET nombre = 'Juan Carlos' WHERE id = 1;

DELETE FROM personasNaturales WHERE nuip = '6767303582';
UPDATE personasNaturales SET clientes_id = 1 WHERE nuip = '6767303582';

DELETE FROM personasJuridicas WHERE nit = '937708198-8';
UPDATE personasJuridicas SET nit = '937708198-9' WHERE nit = '937708198-8';

UPDATE firmas SET nit = '937708198-9' WHERE nit = '830022196-0';

UPDATE espFirmas SET firmas_nit = '937708198-9' WHERE areas_id = 1;

DELETE FROM areas WHERE id = 4;
UPDATE areas SET nombre = 'Derecho Familiar' WHERE id = 3;

UPDATE abogados SET fecha_nacimiento = '01/01/200' WHERE nuip = '2329664486';