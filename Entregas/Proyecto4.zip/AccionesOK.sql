DELETE FROM firmas WHERE nit = '860000719-7';

DELETE FROM clientes WHERE id = 2;
DELETE FROM clientes WHERE id = 1;

DELETE FROM abogados WHERE nuip = '2329664486';
DELETE FROM abogados WHERE nuip = '0022808965';

DELETE FROM perfiles WHERE abogados_nuip = '0022808965';