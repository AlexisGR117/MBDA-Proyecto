-- Consultar los abogados especializados en Derecho Familiar o Derecho Civil
SELECT Area, nuip, Abogado, a�os_experiencia,
       tarifa_minima, calificacion_promedio
    FROM VAbogado
    WHERE Area IN ('&area1', '&area2');
-- Consultar las calificaciones del abogado con nuip 4242574215
SELECT nombre, fecha, comentario, valoracion
    FROM VCalifiaciones
    WHERE nuip = '&NUIP';
-- 4242574215
-- Consultar las firmas que tienen alguna especialidad del abogado con nuip 7370761983
SELECT Area, NIT, Firma, departamento, municipio, direccion
    FROM VFirma
    WHERE nuip = '&NUIP';
-- 7370761983

