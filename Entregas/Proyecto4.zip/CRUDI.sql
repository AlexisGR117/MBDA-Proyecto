CREATE OR REPLACE PACKAGE BODY PC_abogados IS
    PROCEDURE ad_calificacion (xId IN NUMBER, xComentario IN VARCHAR2, xValoracion IN NUMBER,
        xFecha IN DATE, xClientes_id IN NUMBER, xPerfiles_id IN NUMBER)
    IS
    BEGIN
        INSERT INTO calificaciones (id, comentario, valoracion, fecha, clientes_id, perfiles_id)
            VALUES (xId, xComentario, xValoracion, xFecha, xClientes_id, xPerfiles_id);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20001, 'Error al insertar la calificacion');
    END ad_calificacion;
    
    PROCEDURE up_calificacion (xId IN NUMBER, xComentario IN VARCHAR2, xValoracion IN NUMBER,
        xFecha IN DATE, xPerfiles_id IN NUMBER)
    IS
    BEGIN
        UPDATE calificaciones SET comentario = xComentario WHERE id = xId;
        UPDATE calificaciones SET valoracion = xValoracion WHERE id = xId;
        UPDATE calificaciones SET fecha = xFecha WHERE id = xId;
        UPDATE calificaciones SET perfiles_id = xPerfiles_id WHERE id = xId;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20002, 'Error al actualizar la calificacion');
    END up_calificacion;
    
    PROCEDURE de_calificacion (xId IN NUMBER)
    IS
    BEGIN
        DELETE FROM calificaciones WHERE (id = xId);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20003, 'Error al eliminar la calificacion');
    END de_calificacion;
    
    PROCEDURE ad_abogado (xNuip IN VARCHAR2, xCorreo IN VARCHAR2, xTelefono IN VARCHAR2,
        XNombre IN VARCHAR2, xFecha_nacimiento IN DATE, xLugares_id IN NUMBER, xFirmas_nit IN VARCHAR2)
    IS
    BEGIN
        INSERT INTO abogados (nuip, correo, telefono, nombre, fecha_nacimiento, lugares_id, firmas_nit)
            VALUES (XNuip, XCorreo, XTelefono, XNombre, XFecha_nacimiento, XLugares_id, XFirmas_nit);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20004, 'Error al insertar el abogado');
    END ad_abogado;
    
    PROCEDURE up_abogado (xNuip IN VARCHAR2, xCorreo IN VARCHAR2, xTelefono IN VARCHAR2,
        xLugares_id IN NUMBER, xFirmas_nit IN VARCHAR2)
    IS
    BEGIN
        UPDATE abogados SET correo = xCorreo WHERE nuip = xNuip;
        UPDATE abogados SET telefono = xTelefono WHERE nuip = xNuip;
        UPDATE abogados SET lugares_id = xLugares_id WHERE nuip = xNuip;
        UPDATE abogados SET firmas_nit = xFirmas_nit WHERE nuip = xNuip;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20005, 'Error al actualizar el abogado');
    END up_abogado;
    
    PROCEDURE de_abogado (xNuip IN VARCHAR2)
    IS
    BEGIN
        DELETE FROM abogados WHERE (nuip = xNuip);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20006, 'Error al eliminar el abogado');
    END de_abogado;
    
    PROCEDURE ad_espAbog (xAbogados_nuip IN VARCHAR2, xAreas_id IN NUMBER)
    IS
    BEGIN
        INSERT INTO espAbog (abogados_nuip, areas_id)
            VALUES (XAbogados_nuip, XAreas_id);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20007, 'Error al insertar la especialidad del abogado');
    END ad_espAbog;
    
    PROCEDURE de_espAbog (xAbogados_nuip IN VARCHAR2, xAreas_id IN NUMBER)
    IS
    BEGIN
        DELETE FROM espAbog WHERE (abogados_nuip = xAbogados_nuip AND areas_id  = xAreas_id );
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20008, 'Error al eliminar la especialidad del abogado');
    END de_espAbog;
    
    PROCEDURE ad_perfil (xId IN NUMBER, xDescripcion IN VARCHAR2, xA�os_experiencia IN NUMBER,
        XTarifa_minima IN NUMBER, xCalificacion_promedio IN NUMBER, xAbogados_nuip IN VARCHAR2)
    IS
    BEGIN
        INSERT INTO perfiles (id, descripcion, a�os_experiencia, tarifa_minima, calificacion_promedio, abogados_nuip)
            VALUES (XId, XDescripcion, XA�os_experiencia, XTarifa_minima, XCalificacion_promedio, XAbogados_nuip);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20009, 'Error al insertar el perfil');
    END ad_perfil;
    
    PROCEDURE up_perfil (xId IN NUMBER, xDescripcion IN VARCHAR2, xA�os_experiencia IN NUMBER,
        XTarifa_minima IN NUMBER, xCalificacion_promedio IN NUMBER)
    IS
    BEGIN
        UPDATE perfiles SET descripcion = xDescripcion WHERE id = xId;
        UPDATE perfiles SET a�os_experiencia = xA�os_experiencia WHERE id = xId;
        UPDATE perfiles SET tarifa_minima = xTarifa_minima WHERE id = xId;
        UPDATE perfiles SET calificacion_promedio = xCalificacion_promedio WHERE id = xId;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20010, 'Error al actualizar el perfil');
    END up_perfil;
    
    PROCEDURE de_perfil (xId IN NUMBER)
    IS
    BEGIN
        DELETE FROM perfiles WHERE (id = xId);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20011, 'Error al eliminar el perfil');
    END de_perfil;
    
    PROCEDURE ad_estudio(xId IN NUMBER, xTitulo IN VARCHAR2, xUniversidad IN VARCHAR2, 
        XFecha_inicio IN DATE, XFecha_final IN DATE, xPerfiles_id IN NUMBER)
    IS
    BEGIN
        INSERT INTO estudios (id, titulo, universidad, fecha_inicio, fecha_final, perfiles_id)
            VALUES (XId, XTitulo, XUniversidad, XFecha_inicio, XFecha_final, XPerfiles_id);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20012, 'Error al insertar el estudio del abogado');
    END ad_estudio;
    
    PROCEDURE de_estudio (xId IN NUMBER)
    IS
    BEGIN
        DELETE FROM estudios WHERE (id  = xId );
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20013, 'Error al eliminar el estudio del abogado');
    END de_estudio;
    
    PROCEDURE ad_tarjetaProfesional(XNumero IN VARCHAR2, xFecha_expedicion IN DATE,
        xFecha_grado IN DATE, xUniversidad IN VARCHAR2, xConsejo_seccional IN VARCHAR2, 
        XAbogados_nuip IN VARCHAR2)
    IS
    BEGIN
        INSERT INTO tarjetasProfesionales (numero, fecha_expedicion, fecha_grado, universidad, consejo_seccional, abogados_nuip)
            VALUES (XNumero, XFecha_expedicion, XFecha_grado, XUniversidad, XConsejo_seccional, XAbogados_nuip);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20014, 'Error al insertar la tarjeta profesional del abogado');
    END ad_tarjetaProfesional;
    
    FUNCTION co_abogado (XArea IN VARCHAR2) RETURN SYS_REFCURSOR
    AS s_cursor SYS_REFCURSOR;
    BEGIN
        OPEN s_cursor FOR
            SELECT Area, nuip, Abogado, a�os_experiencia,
                   tarifa_minima, calificacion_promedio
                FROM VAbogado
                WHERE Area IN (XArea);
        RETURN s_cursor;
    END co_abogado;
    
    FUNCTION co_calificacion (xNuip IN VARCHAR2) RETURN SYS_REFCURSOR
    AS s_cursor SYS_REFCURSOR;
    BEGIN
        OPEN s_cursor FOR
            SELECT nombre, fecha, comentario, valoracion
                FROM VCalifiaciones
                WHERE nuip = XNuip;
        RETURN s_cursor;
    END co_calificacion;
END PC_abogados;
/
CREATE OR REPLACE PACKAGE BODY PC_asesorias IS
    PROCEDURE ad_asesoria (xId IN NUMBER, xDescripcion IN VARCHAR2, xFecha IN DATE,
        xDuracion IN NUMBER, xPrecio IN NUMBER, xAbogados_nuip IN VARCHAR2, xClientes_id IN NUMBER)
    IS
    BEGIN
        INSERT INTO asesorias (id, descripcion, fecha, duracion, precio, abogados_nuip, clientes_id)
            VALUES (XId, XDescripcion, XFecha, XDuracion, XPrecio, XAbogados_nuip, XClientes_id);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-200015, 'Error al insertar la asesoria');
    END ad_asesoria;
    
    PROCEDURE up_asesoria (xId IN NUMBER, xDescripcion IN VARCHAR2, xFecha IN DATE,
        xDuracion IN NUMBER, xPrecio IN NUMBER, xClientes_id IN NUMBER)
    IS
    BEGIN
        UPDATE asesorias SET descripcion = xDescripcion WHERE id = xId;
        UPDATE asesorias SET fecha = xFecha WHERE id = xId;
        UPDATE asesorias SET duracion = xDuracion WHERE id = xId;
        UPDATE asesorias SET precio = xPrecio WHERE id = xId;
        UPDATE asesorias SET clientes_id = xClientes_id WHERE id = xId;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20016, 'Error al actualizar la asesoria');
    END up_asesoria;
END PC_asesorias;