CREATE INDEX IFirmas
    ON firmas(lugares_id);
CREATE INDEX IAbogados
    ON abogados(lugares_id);
CREATE INDEX IPerfiles1
    ON perfiles(a�os_experiencia DESC);
CREATE INDEX IPerfiles12
    ON perfiles(tarifa_minima DESC);
CREATE INDEX IPerfiles3
    ON perfiles(calificacion_promedio DESC);
CREATE INDEX ISolicitudes
    ON solicitudes(fecha_envio ASC);
CREATE INDEX IContratos
    ON contratos(fecha_firma ASC);