CREATE OR REPLACE VIEW VAbogado AS
    SELECT areas.nombre AS Area, nuip, abogados.nombre AS Abogado, a�os_experiencia,
           tarifa_minima, calificacion_promedio
        FROM abogados JOIN espAbog ON (nuip = abogados_nuip)
            JOIN areas ON (areas_id = areas.id)
            JOIN perfiles ON (perfiles.abogados_nuip = abogados.nuip)
        ORDER BY a�os_experiencia DESC, calificacion_promedio DESC, tarifa_minima DESC;
CREATE OR REPLACE VIEW VCalifiaciones AS 
    SELECT nuip, nombre, fecha, comentario, valoracion
        FROM abogados JOIN perfiles ON (nuip = abogados_nuip)
            JOIN calificaciones ON (perfiles_id = perfiles.id)
        ORDER BY valoracion;
CREATE OR REPLACE VIEW VFirma AS
    SELECT nuip, areas.nombre AS Area, firmas.nit AS NIT, firmas.nombre AS Firma, departamento, municipio, direccion
    FROM abogados JOIN espAbog ON (nuip = abogados_nuip)
        JOIN espFirmas ON (espFirmas.areas_id = espAbog.areas_id)
        JOIN areas ON (espAbog.areas_id = areas.id)
        JOIN firmas ON (espFirmas.firmas_nit = firmas.nit)
        JOIN lugares ON (lugares.id = firmas.lugares_id);