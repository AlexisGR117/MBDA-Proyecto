-- lugares
INSERT INTO lugares
    VALUES (1, 'Cundinamarca', 'Chia', Null);
INSERT INTO lugares
    VALUES (2, 'Antioquia', 'Medellin', 'Carrea 29C 10C -125');
INSERT INTO lugares
    VALUES (3, 'Bogota', 'Bogota', Null);
INSERT INTO lugares
    VALUES (4, 'Atl�ntico', 'Barranquilla', 'Cra 53 # 82 � 86');
INSERT INTO lugares
    VALUES (5, 'Bogota', 'Bogota', 'AV CL 82 10 62 P 5');
-- firmas
INSERT INTO firmas
    VALUES ('800134536-3', 'Brigard Urrutia Abogados S. A. S.',
            '6013462011', 'info@bu.com.co', 2);
INSERT INTO firmas
    VALUES ('830022196-0', 'Posse Herrera Ruiz S. A.',
            '6013257300', 'phr@phrlegal.com', 4);
INSERT INTO firmas 
    VALUES('900532339-9', 'Baker Mckenzie S A S',
            '6016341500', 'alejandromesa@bakermckenzie.com', 5);
INSERT INTO firmas
    VALUES ('800175087-3', 'Gomez Pinzon Abogados S A S',
            '6013192900', 'gpa@gomezpinzon.com', 3);
INSERT INTO firmas 
    VALUES('860000719-7', 'Jose Lloreda Camacho Co S A S',
            '6016069701', 'lloreda@lloredacamacho.com', 3);
-- abogados
INSERT INTO abogados
    VALUES ('1968720863', 'ldericut0@disqus.com', '1454913181',
            'Lilith Dericut', '07/04/1963', 1, '860000719-7');
INSERT INTO abogados
    VALUES ('0022808965', 'iutting2@gizmodo.com', '4799094623',
            'Ilaire Utting', '23/12/1941', 2, '800134536-3');
INSERT INTO abogados
    VALUES ('2329664486', 'vcabena1@opensource.org', '9857077591',
            'Valeria Cabena', '13/04/1961', 1, NULL);
INSERT INTO abogados
    VALUES ('8153587439', 'hstiff3@statcounter.com', '2065101028',
            'Haskell Stiff', '14/04/1977', 2, '800134536-3');
INSERT INTO abogados
    VALUES ('8437980011', 'helan4@issuu.com', '3369550695',
            'Harri Elan', '06/02/1987', 3, NULL);
-- clientes
INSERT INTO clientes
    VALUES (1, 'Deborah McReedy', 'dmcreedy0@cbc.ca',
            '6896171464', '1968720863');
INSERT INTO clientes
    VALUES (2, 'Alberto Slevin', 'aslevin1@1und1.de',
            '7107979529', NULL);
INSERT INTO clientes
    VALUES (3, 'Brendin Keeton', 'bkeeton2@w3.org',
            '1184578890', '8153587439');
INSERT INTO clientes
    VALUES (4, 'Brigit Gullefant', 'bgullefant3@reference.com',
            '6171881962', '0022808965');
INSERT INTO clientes
    VALUES (5, 'Shirlene Smewings', 'ssmewings4@woothemes.com',
            '2834934445', NULL);
INSERT INTO clientes
    VALUES (6, 'Toy, Sipes and Kovacek', 'ljacomb5@cnet.com',
            '1947505871', '8437980011');
INSERT INTO clientes
    VALUES (7, 'Nader, Rohan and Braun', 'apenvarne6@bloglovin.com',
            '3836149903', '0022808965');
INSERT INTO clientes
    VALUES (8, 'Heaney, Murphy and Stroman', 'byann7@angelfire.com',
            '7869119948', '8437980011');
INSERT INTO clientes
    VALUES (9, 'O Hara LLC', 'zrhelton8@state.gov',
            '5831279397', '1968720863');
INSERT INTO clientes
    VALUES (10, 'Reichel, Abernathy and Lockman', 'moconcannona@twitter.com', 
            '6927071710', '8437980011');
-- areas
INSERT INTO areas
    VALUES (1, 'Derecho Fiscal', 'Control de los ingresos p�blicos de los Estados');
INSERT INTO areas
    VALUES (2, 'Administrativa', 'Formas de actuaci�n de administraciones');
INSERT INTO areas
    VALUES (3, 'Derecho del Trabajo', 'Relaci�n entre empresarios y trabajadores');
INSERT INTO areas
    VALUES (4, 'Derecho Civil', 'Relaciones civiles de las personas');
INSERT INTO areas
    VALUES (5, 'Derecho Familiar', 'Asuntos que afectan a los miembros de una familiar');
-- juzgados
INSERT INTO juzgados
    VALUES (1, 'Sonsing', 'CI', 'claughlin0@slideshare.net', '6037461772', 1);
INSERT INTO juzgados
    VALUES (2, 'Viva', 'LA', 'mflowith1@cocolognifty.com', '8898026986', 1);
INSERT INTO juzgados
    VALUES (3, 'Sonair', 'PA', 'wlitherborough2@soup.io', '8609913520', 3);
INSERT INTO juzgados
    VALUES (4, 'Opela', 'PE', 'rosheeryne3@dailymotion.com', '8812109053', 1);
INSERT INTO juzgados
    VALUES (5, 'Quo Lux', 'CI', 'fchildes4@lulu.com', '7447599900', 3);
-- casos
INSERT INTO casos
    VALUES (1, 'Activo', NULL);
INSERT INTO casos
    VALUES (2, 'Cancelado', NULL);
INSERT INTO casos
    VALUES (3, 'Terminado', 'Perdido');
INSERT INTO casos
    VALUES (4, 'Terminado', 'Ganado');
INSERT INTO casos
    VALUES (5, 'Activo', NULL);
-- jueces
INSERT INTO jueces
    VALUES ('7286181653', 'Ellynn Ferrierio', 'eferrierio0@artisteer.com', '4596789009');
INSERT INTO jueces
    VALUES ('7947005044', 'Carma Gussin', 'cgussin1@illinois.edu', NULL);
INSERT INTO jueces
    VALUES ('6105289081', 'Heather MacKee', 'hmackee2@upenn.edu', '7935564036');
INSERT INTO jueces
    VALUES ('1217837299', 'Arline Verbeek', NULL, '7617107993');
INSERT INTO jueces
    VALUES ('6783768503', 'Georgianna Codeman', 'gcodeman4@tinypic.com', '7892640821');
-- fundamentosDerechos
INSERT INTO fundamentosDerechos
    VALUES (1, 'Articulo uno', 'Descripcion articulo uno');
INSERT INTO fundamentosDerechos
    VALUES (2, 'Articulo dos', 'Descripcion articulo dos');
INSERT INTO fundamentosDerechos
    VALUES (3, 'Articulo tres', 'Descripcion articulo tres');
INSERT INTO fundamentosDerechos
    VALUES (4, 'Articulo cuatro', 'Descripcion articulo cuatro');
INSERT INTO fundamentosDerechos
    VALUES (5, 'Articulo cinco', 'Descripcion articulo cinco');
-- demandas
INSERT INTO demandas
    VALUES (1, 6, 'Pretenciones uno', 5000000, '17/06/2018', 1, 3, 1);
INSERT INTO demandas
    VALUES (2, 3, 'Pretenciones dos', 2000000, '02/09/2019', 1, 3, 2);
INSERT INTO demandas
    VALUES (3, 4, 'Pretenciones tres', NULL, '23/02/2020', 3, 2, 3);
INSERT INTO demandas
    VALUES (4, 5, 'Pretenciones cuatro', NULL, '13/05/2021', 4, 1, 4);
INSERT INTO demandas
    VALUES (5, 1, 'Pretenciones cinco', 9300000, '01/11/2022', 5, 5, 5);
-- hechos
INSERT INTO hechos
    VALUES (1, 3, 5, '21/08/2022', 'Descripcion hechos uno');
INSERT INTO hechos
    VALUES (2, 3, 3, '29/03/2021', 'Descripcion hechos dos');
INSERT INTO hechos
    VALUES (3, 1, 4, '12/01/2020', 'Descripcion hechos tres');
INSERT INTO hechos
    VALUES (4, 3, 1, '24/05/2018', 'Descripcion hechos cuatro');
INSERT INTO hechos
    VALUES (5, 1, 1, '24/05/2018', 'Descripcion hechos cinco');
-- perfiles
INSERT INTO perfiles
    VALUES (1, 'Descripcion perfil uno', 15, 500000, NULL, '1968720863');
INSERT INTO perfiles
    VALUES (2, 'Descripcion perfil dos', 9, 1500000, NULL, '0022808965');
INSERT INTO perfiles 
    VALUES (3, 'Descripcion perfil tres', 21, 900000, NULL, '2329664486');
INSERT INTO perfiles
    VALUES (4, 'Descripcion perfil cuatro', 5, 200000, NULL, '8153587439');
INSERT INTO perfiles
    VALUES (5, 'Descripcion perfil cinco', 26, 1900000, NULL, '8437980011');
-- calificaciones
INSERT INTO calificaciones
    VALUES (1, 'Comentario uno', 3, '02/04/2022', 1, 4);
INSERT INTO calificaciones
    VALUES (2, 'Comentario dos', 3.5, '02/04/2022', 1, 3);
INSERT INTO calificaciones
    VALUES (3, NULL, 4, '02/04/2022', 2, 1);
INSERT INTO calificaciones
    VALUES (4, 'Comentario cuatro', 2.3, '02/04/2022', 3, 2);
INSERT INTO calificaciones
    VALUES (5, 'Comentario cinco', 5, '02/04/2022', 5, 1);
-- espAbog
INSERT INTO espAbog
    VALUES ('0022808965', 1);
INSERT INTO espAbog
    VALUES ('0022808965', 5);
INSERT INTO espAbog
    VALUES ('0022808965', 3);
INSERT INTO espAbog
    VALUES ('2329664486', 4);
INSERT INTO espAbog
    VALUES ('8437980011', 5);
-- espFirmas
INSERT INTO espFirmas
    VALUES ('800134536-3', 4);
INSERT INTO espFirmas
    VALUES ('900532339-9', 5);
INSERT INTO espFirmas
    VALUES ('900532339-9', 1);
INSERT INTO espFirmas
    VALUES ('860000719-7', 4);
INSERT INTO espFirmas
    VALUES ('860000719-7', 3);
-- tarjetasProfesionales
INSERT INTO tarjetasProfesionales
    VALUES ('430949', '09/07/1992', '06/12/1987', 'Universitas Negeri Jakarta',
            'Consejo uno', '1968720863');
INSERT INTO tarjetasProfesionales
    VALUES ('910517', '03/03/2016', '25/02/1974', 'Morioka College',
            'Consejo dos', '0022808965');
INSERT INTO tarjetasProfesionales
    VALUES ('030359', '26/10/2021', '14/04/2003', 'Saito College',
            'Consejo tres', '2329664486');
INSERT INTO tarjetasProfesionales
    VALUES ('065614', '18/01/2007', '14/01/1986', 'Earlham College',
            'Consejo cuatro', '8153587439');
INSERT INTO tarjetasProfesionales
    VALUES ('317972', '26/06/2010', '26/12/1985', 'University of Pisa',
            'Consejo cinco', '8437980011');
-- personasNaturales
INSERT INTO personasNaturales
    VALUES ('6767303582', '14/11/1960', 1);
INSERT INTO personasNaturales
    VALUES ('8413129822', '09/07/1980', 2);
INSERT INTO personasNaturales
    VALUES ('1796951213', '28/03/1983', 3);
INSERT INTO personasNaturales
    VALUES ('3801188272', '29/08/1960', 4);
INSERT INTO personasNaturales
    VALUES ('4525941159', '11/10/1980', 5);
-- personasJuridicas
INSERT INTO personasJuridicas
    VALUES ('006329254-8', 'Gusikowski', 6);
INSERT INTO personasJuridicas
    VALUES ('937708198-8', 'Predovic-Kuhlman', 7);
INSERT INTO personasJuridicas
    VALUES ('391708102-3', 'Carter Inc', 8);
INSERT INTO personasJuridicas
    VALUES ('083439326-4', 'Bins Group', 9);
INSERT INTO personasJuridicas
    VALUES ('058301844-4', 'Toy and Sons', 10);
-- contratos
INSERT INTO contratos
    VALUES (1, '10/03/2022', 'Descripcion uno', 'Forma uno', 1000000,
            7, '1968720863', 1);
INSERT INTO contratos
    VALUES (2, '17/11/2016', 'Descripcion dos', 'Forma dos', 2400000,
            3, '0022808965', 1);
INSERT INTO contratos
    VALUES (3, '26/07/2018', 'Descripcion tres', 'Forma tres', NULL,
            1, '0022808965', 3);
INSERT INTO contratos
    VALUES (4, '31/08/2019', 'Descripcion cuatro', 'Forma cuatro', 900000,
            8, '8153587439', 1);
INSERT INTO contratos
    VALUES (5, '09/10/2019', 'Descripcion cinco', 'Forma cinco', NULL,
            1, '8437980011', 3);
-- audicencias
INSERT INTO audiencias
    VALUES (1, '09/04/2020', 90, '7286181653', 2);
INSERT INTO audiencias
    VALUES (2, '05/12/2018', 178, '7947005044', 2);
INSERT INTO audiencias
    VALUES (3, '12/07/2015', 77, '6105289081', 1);
INSERT INTO audiencias
    VALUES (4, '03/03/2020', 139, '6105289081', 1);
INSERT INTO audiencias
    VALUES (5, '18/09/2016', 77, '6783768503', 4);
-- solicitudes
INSERT INTO solicitudes
    VALUES (1, 'Descripcion uno', '26/08/2019', 6, '8437980011');
INSERT INTO solicitudes
    VALUES (2, 'Descripcion dos', '01/01/2022', 3, '8153587439');
INSERT INTO solicitudes
    VALUES (3, 'Descripcion tres', '21/02/2021', 9, '1968720863');
INSERT INTO solicitudes
    VALUES (4, 'Descripcion cuatro', '11/10/2019', 9, '0022808965');
INSERT INTO solicitudes
    VALUES (5, 'Descripcion cinco', '10/11/2021', 1, '8437980011');
-- estudios
INSERT INTO estudios
    VALUES (1, 'Clinical Specialist', 'Binh Duong University',
            '09/02/2011', '15/05/2019', 1);
INSERT INTO estudios
    VALUES (2, 'Computer Systems Analyst', 'Universit� Vincennes Saint',
            '25/12/2010', '23/12/2021', 2);
INSERT INTO estudios
    VALUES (3, 'Actuary', 'University of Gjirokstra', '19/09/2010',
            '29/11/2019', 3);
INSERT INTO estudios
    VALUES (4, 'Software Engineer III', 'Evangelische Hochschule',
            '13/08/2012', '21/06/2021', 4);
INSERT INTO estudios
    VALUES (5, 'Environmental Specialist', 'Universidade Fernando Pessoa',
            '13/09/2015', '11/03/2019', 5);
-- asesorias
INSERT INTO asesorias
    VALUES (1, 'Descripcion uno', '23/03/2019', 22, 4743308, '0022808965', 6);
INSERT INTO asesorias
    VALUES (2, 'Descripcion dos', '03/12/2016', 41, 2489447, '8437980011', 3);
INSERT INTO asesorias
    VALUES (3, 'Descripcion tres', '20/09/2017', 39, 3448152, '2329664486', 10);
INSERT INTO asesorias
    VALUES (4, 'Descripcion cuatro', '03/07/2020', 157, 2610243, '2329664486', 5);
INSERT INTO asesorias
    VALUES (5, 'Descripcion cinco', '19/06/2018', 160, 4184541, '1968720863', 3);
-- revisiones
INSERT INTO revisiones
    VALUES (2, 8);
INSERT INTO revisiones
    VALUES (2, 6);
INSERT INTO revisiones
    VALUES (1, 3);
INSERT INTO revisiones
    VALUES (5, 10);
INSERT INTO revisiones
    VALUES (3, 10);
-- sentencias
INSERT INTO sentencias
    VALUES (117, '25/08/2019', 'Fallo uno', 2, '7286181653');
INSERT INTO sentencias
    VALUES (157, '27/05/2019', 'Fallo dos', 1, '7947005044');
INSERT INTO sentencias
    VALUES (181, '30/12/2016', 'Fallo tres', 5, '6105289081');
INSERT INTO sentencias
    VALUES (234, '10/09/2018', 'Fallo cuatro', 4, '1217837299');
INSERT INTO sentencias
    VALUES (146, '24/07/2016', 'Fallo cinco', 3, '6783768503');
-- pruebas
INSERT INTO pruebas
    VALUES (1, 'INP', 'Descripcion uno', 'medio uno', 1);
INSERT INTO pruebas
    VALUES (2, 'DPU', 'Descripcion dos', 'medio dos', 2);
INSERT INTO pruebas
    VALUES (3, 'REJ', NULL, 'medio tres', 2);
INSERT INTO pruebas
    VALUES (4, 'DIP', 'Descripcion cuatro', 'medio cuatro', 3);
INSERT INTO pruebas
    VALUES (5, 'INP', 'Descripcion cinco', 'medio cinco', 5);
-- demFun
INSERT INTO demFun
    VALUES (4, 2);
INSERT INTO demFun
    VALUES (4, 1);
INSERT INTO demFun
    VALUES (1, 2);
INSERT INTO demFun
    VALUES (5, 3);
INSERT INTO demFun
    VALUES (3, 5);