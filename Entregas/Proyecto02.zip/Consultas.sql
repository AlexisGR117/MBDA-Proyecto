-- Consultar los abogados especializados en Derecho Familiar o Derecho Civil
SELECT areas.nombre, nuip, abogados.nombre, a�os_experiencia
    FROM abogados JOIN espAbog ON (nuip = abogados_nuip)
        JOIN areas ON (areas_id = areas.id)
        JOIN perfiles ON (perfiles.abogados_nuip = abogados.nuip)
    WHERE areas.nombre IN ('Derecho Familiar', 'Derecho Civil')
    ORDER BY a�os_experiencia DESC;
-- Consultar las calificaciones del abogado con nuip 1968720863
SELECT nuip, nombre, calificacion_promedio, comentario, valoracion
    FROM abogados JOIN perfiles ON (nuip = abogados_nuip)
        JOIN calificaciones ON (perfiles_id = perfiles.id)
    WHERE nuip = '1968720863'
    ORDER BY valoracion;
-- Consultar las firmas que tienen alguna especialidad del abogado con nuip 0022808965
SELECT firmas.nit, firmas.nombre AS Firma, abogados.nombre, areas.nombre AS Area
    FROM abogados JOIN espAbog ON (nuip = abogados_nuip)
        JOIN espFirmas ON (espFirmas.areas_id = espAbog.areas_id)
        JOIN areas ON (espAbog.areas_id = areas.id)
        JOIN firmas ON (espFirmas.firmas_nit = firmas.nit)
    WHERE nuip = '0022808965';
    