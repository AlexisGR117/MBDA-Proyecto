CREATE OR REPLACE PACKAGE BODY PC_abogados IS
    PROCEDURE ad_calificacion (xId IN NUMBER, xComentario IN VARCHAR2, xValoracion IN NUMBER,
        xFecha IN DATE, xClientes_id IN NUMBER, xPerfiles_id IN NUMBER)
    IS
    BEGIN
        INSERT INTO calificaciones (id, comentario, valoracion, fecha, clientes_id, perfiles_id)
            VALUES (xId, xComentario, xValoracion, xFecha, xClientes_id, xPerfiles_id);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20001, 'Error al insertar la calificacion');
    END ad_calificacion;
    
    PROCEDURE up_calificacion (xId IN NUMBER, xComentario IN VARCHAR2, xValoracion IN NUMBER,
        xFecha IN DATE, xPerfiles_id IN NUMBER)
    IS
    BEGIN
        UPDATE calificaciones SET comentario = xComentario WHERE id = xId;
        UPDATE calificaciones SET valoracion = xValoracion WHERE id = xId;
        UPDATE calificaciones SET fecha = xFecha WHERE id = xId;
        UPDATE calificaciones SET perfiles_id = xPerfiles_id WHERE id = xId;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20002, 'Error al actualizar la calificacion');
    END up_calificacion;
    
    PROCEDURE de_calificacion (xId IN NUMBER)
    IS
    BEGIN
        DELETE FROM calificaciones WHERE (id = xId);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20003, 'Error al eliminar la calificacion');
    END de_calificacion;
    
    PROCEDURE ad_abogado (xNuip IN VARCHAR2, xCorreo IN VARCHAR2, xTelefono IN VARCHAR2,
        xNombre IN VARCHAR2, xFecha_nacimiento IN DATE, xLugares_id IN NUMBER, xFirmas_nit IN VARCHAR2)
    IS
    BEGIN
        INSERT INTO abogados (nuip, correo, telefono, nombre, fecha_nacimiento, lugares_id, firmas_nit)
            VALUES (xNuip, xCorreo, xTelefono, xNombre, xFecha_nacimiento, xLugares_id, xFirmas_nit);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20004, 'Error al insertar el abogado');
    END ad_abogado;
    
    PROCEDURE up_abogado (xNuip IN VARCHAR2, xCorreo IN VARCHAR2, xTelefono IN VARCHAR2,
        xLugares_id IN NUMBER, xFirmas_nit IN VARCHAR2)
    IS
    BEGIN
        UPDATE abogados SET correo = xCorreo WHERE nuip = xNuip;
        UPDATE abogados SET telefono = xTelefono WHERE nuip = xNuip;
        UPDATE abogados SET lugares_id = xLugares_id WHERE nuip = xNuip;
        UPDATE abogados SET firmas_nit = xFirmas_nit WHERE nuip = xNuip;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20005, 'Error al actualizar el abogado');
    END up_abogado;
    
    PROCEDURE de_abogado (xNuip IN VARCHAR2)
    IS
    BEGIN
        DELETE FROM abogados WHERE (nuip = xNuip);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20006, 'Error al eliminar el abogado');
    END de_abogado;
    
    PROCEDURE ad_espAbog (xAbogados_nuip IN VARCHAR2, xAreas_id IN NUMBER)
    IS
    BEGIN
        INSERT INTO espAbog (abogados_nuip, areas_id)
            VALUES (xAbogados_nuip, xAreas_id);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20007, 'Error al insertar la especialidad del abogado');
    END ad_espAbog;
    
    PROCEDURE de_espAbog (xAbogados_nuip IN VARCHAR2, xAreas_id IN NUMBER)
    IS
    BEGIN
        DELETE FROM espAbog WHERE (abogados_nuip = xAbogados_nuip AND areas_id  = xAreas_id );
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20008, 'Error al eliminar la especialidad del abogado');
    END de_espAbog;
    
    PROCEDURE ad_perfil (xId IN NUMBER, xDescripcion IN VARCHAR2, xA�os_experiencia IN NUMBER,
        xTarifa_minima IN NUMBER, xCalificacion_promedio IN NUMBER, xAbogados_nuip IN VARCHAR2)
    IS
    BEGIN
        INSERT INTO perfiles (id, descripcion, a�os_experiencia, tarifa_minima, calificacion_promedio, abogados_nuip)
            VALUES (xId, xDescripcion, xA�os_experiencia, xTarifa_minima, xCalificacion_promedio, xAbogados_nuip);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20009, 'Error al insertar el perfil');
    END ad_perfil;
    
    PROCEDURE up_perfil (xId IN NUMBER, xDescripcion IN VARCHAR2, xA�os_experiencia IN NUMBER,
        xTarifa_minima IN NUMBER, xCalificacion_promedio IN NUMBER)
    IS
    BEGIN
        UPDATE perfiles SET descripcion = xDescripcion WHERE id = xId;
        UPDATE perfiles SET a�os_experiencia = xA�os_experiencia WHERE id = xId;
        UPDATE perfiles SET tarifa_minima = xTarifa_minima WHERE id = xId;
        UPDATE perfiles SET calificacion_promedio = xCalificacion_promedio WHERE id = xId;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20010, 'Error al actualizar el perfil');
    END up_perfil;
    
    PROCEDURE de_perfil (xId IN NUMBER)
    IS
    BEGIN
        DELETE FROM perfiles WHERE (id = xId);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20011, 'Error al eliminar el perfil');
    END de_perfil;
    
    PROCEDURE ad_estudio(xId IN NUMBER, xTitulo IN VARCHAR2, xUniversidad IN VARCHAR2, 
        xFecha_inicio IN DATE, xFecha_final IN DATE, xPerfiles_id IN NUMBER)
    IS
    BEGIN
        INSERT INTO estudios (id, titulo, universidad, fecha_inicio, fecha_final, perfiles_id)
            VALUES (xId, xTitulo, xUniversidad, xFecha_inicio, xFecha_final, xPerfiles_id);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20012, 'Error al insertar el estudio del abogado');
    END ad_estudio;
    
    PROCEDURE de_estudio (xId IN NUMBER)
    IS
    BEGIN
        DELETE FROM estudios WHERE (id  = xId );
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20013, 'Error al eliminar el estudio del abogado');
    END de_estudio;
    
    PROCEDURE ad_tarjetaProfesional(xNumero IN VARCHAR2, xFecha_expedicion IN DATE,
        xFecha_grado IN DATE, xUniversidad IN VARCHAR2, xConsejo_seccional IN VARCHAR2, 
        xAbogados_nuip IN VARCHAR2)
    IS
    BEGIN
        INSERT INTO tarjetasProfesionales (numero, fecha_expedicion, fecha_grado, universidad, consejo_seccional, abogados_nuip)
            VALUES (xNumero, xFecha_expedicion, xFecha_grado, xUniversidad, xConsejo_seccional, xAbogados_nuip);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20014, 'Error al insertar la tarjeta profesional del abogado');
    END ad_tarjetaProfesional;
    
    FUNCTION co_abogado (xArea IN VARCHAR2) RETURN SYS_REFCURSOR
    AS s_cursor SYS_REFCURSOR;
    BEGIN
        OPEN s_cursor FOR
            SELECT Area, nuip, Abogado, a�os_experiencia,
                   tarifa_minima, calificacion_promedio
                FROM VAbogado
                WHERE Area IN (xArea);
        RETURN s_cursor;
    END co_abogado;
    
    FUNCTION co_calificacion (xNuip IN VARCHAR2) RETURN SYS_REFCURSOR
    AS s_cursor SYS_REFCURSOR;
    BEGIN
        OPEN s_cursor FOR
            SELECT NombreCliente, fecha, comentario, valoracion
                FROM VCalifiaciones
                WHERE nuip = xNuip;
        RETURN s_cursor;
    END co_calificacion;
END PC_abogados;
/
CREATE OR REPLACE PACKAGE BODY PC_asesorias IS
    PROCEDURE ad_asesoria (xId IN NUMBER, xDescripcion IN VARCHAR2, xFecha IN DATE,
        xDuracion IN NUMBER, xPrecio IN NUMBER, xAbogados_nuip IN VARCHAR2, xClientes_id IN NUMBER)
    IS
    BEGIN
        INSERT INTO asesorias (id, descripcion, fecha, duracion, precio, abogados_nuip, clientes_id)
            VALUES (xId, xDescripcion, xFecha, xDuracion, xPrecio, xAbogados_nuip, xClientes_id);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20015, 'Error al insertar la asesoria');
    END ad_asesoria;
    
    PROCEDURE up_asesoria (xId IN NUMBER, xDescripcion IN VARCHAR2, xFecha IN DATE,
        xDuracion IN NUMBER, xPrecio IN NUMBER, xClientes_id IN NUMBER)
    IS
    BEGIN
        UPDATE asesorias SET descripcion = xDescripcion WHERE id = xId;
        UPDATE asesorias SET fecha = xFecha WHERE id = xId;
        UPDATE asesorias SET duracion = xDuracion WHERE id = xId;
        UPDATE asesorias SET precio = xPrecio WHERE id = xId;
        UPDATE asesorias SET clientes_id = xClientes_id WHERE id = xId;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20016, 'Error al actualizar la asesoria');
    END up_asesoria;
END PC_asesorias;
/
CREATE OR REPLACE PACKAGE BODY PC_lugares IS
    PROCEDURE ad_lugar (xId IN NUMBER, xDepartamento IN VARCHAR2, xMunicipio IN VARCHAR2,
        xDireccion IN VARCHAR2)
    IS
    BEGIN
        INSERT INTO lugares (id, departamento, municipio, direccion)
            VALUES (xId, xDepartamento, xMunicipio, xDireccion);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20017, 'Error al insertar el lugar');
    END ad_lugar;
END PC_lugares;
/
CREATE OR REPLACE PACKAGE BODY PC_areas IS
    PROCEDURE ad_area (xId IN NUMBER, xNombre IN VARCHAR2, xDescripcion IN VARCHAR2)
    IS
    BEGIN
        INSERT INTO areas (id, nombre, descripcion)
            VALUES (xId, xNombre, xDescripcion);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20018, 'Error al insertar el area');
    END ad_area;
    
    PROCEDURE up_area (xId IN NUMBER, xDescripcion IN VARCHAR2)
    IS
    BEGIN
        UPDATE areas SET descripcion = xDescripcion WHERE id = xId;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20019, 'Error al actualizar el area');
    END up_area;
END PC_areas;
/
CREATE OR REPLACE PACKAGE BODY PC_firmas IS
    PROCEDURE ad_firma (xNit IN VARCHAR2, xNombre IN VARCHAR, xTelefono IN VARCHAR, 
        xCorreo IN VARCHAR2, xLugares_id IN NUMBER)
    IS
    BEGIN
        INSERT INTO firmas (nit, nombre, telefono, correo, lugares_id)
            VALUES (xNit, xNombre, xTelefono, xCorreo, xLugares_id);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20020, 'Error al insertar la firma');
    END ad_firma;
    
    PROCEDURE up_firma (xNit IN VARCHAR2, xNombre IN VARCHAR, xTelefono IN VARCHAR, 
        xCorreo IN VARCHAR2, xLugares_id IN NUMBER)
    IS
    BEGIN
        UPDATE firmas SET nombre = xNombre WHERE nit = xNIT;
        UPDATE firmas SET telefono = xTelefono WHERE nit = xNIT;
        UPDATE firmas SET correo = xCorreo WHERE nit = xNIT;
        UPDATE firmas SET lugares_id = xLugares_id WHERE nit = xNIT;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20021, 'Error al actualizar la firma');
    END up_firma;
    
    PROCEDURE de_firma (xNit IN VARCHAR2)
    IS
    BEGIN
        DELETE FROM firmas WHERE (nit = xNit);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20022, 'Error al eliminar la firma');
    END de_firma;

    PROCEDURE ad_espFirma (xFirmas_nit IN VARCHAR2, xAreas_id IN NUMBER)
    IS
    BEGIN
        INSERT INTO espFirmas (firmas_nit, areas_id)
            VALUES (xFirmas_nit, xAreas_id);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20023, 'Error al insertar la especialidad de la firma');
    END ad_espFirma;
    
    PROCEDURE de_espFirma (xFirmas_nit IN VARCHAR2, xAreas_id IN NUMBER)
    IS
    BEGIN
        DELETE FROM espFirmas WHERE (firmas_nit = xFirmas_nit AND areas_id  = xAreas_id );
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20024, 'Error al eliminar la especialidad de la firma');
    END de_espfirma;
    
    FUNCTION co_firma (xNuip IN VARCHAR2) RETURN SYS_REFCURSOR
    AS s_cursor SYS_REFCURSOR;
    BEGIN
        OPEN s_cursor FOR
            SELECT Area, NIT, Firma, departamento, municipio, direccion
                FROM VFirma
                WHERE nuip = xNuip;
        RETURN s_cursor;
    END co_firma;
END PC_firmas;
/
CREATE OR REPLACE PACKAGE BODY PC_contratos IS
    PROCEDURE ad_contrato (xId IN NUMBER, xFecha_firma IN DATE, xDescripcion IN VARCHAR2,
        xForma_pago IN VARCHAR2, xRemuneracion IN NUMBER, xClientes_id IN NUMBER,
        xAbogados_nuip IN VARCHAR, xLugares_id IN NUMBER)
    IS
    BEGIN
        INSERT INTO contratos (id, fecha_firma, descripcion, forma_pago, remuneracion, clientes_id, abogados_nuip, lugares_id)
            VALUES (xId, xFecha_firma, xDescripcion, xForma_pago, xRemuneracion, xClientes_id, xAbogados_nuip, xLugares_id);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20025, 'Error al insertar el contrato');
    END ad_contrato;
    
    PROCEDURE up_contrato (xId IN NUMBER, xDescripcion IN VARCHAR2, xForma_pago IN VARCHAR2,
        xRemuneracion IN NUMBER, xLugares_id IN NUMBER)
    IS
    BEGIN
        UPDATE contratos SET descripcion = xDescripcion WHERE id = xId;
        UPDATE contratos SET forma_pago = xForma_pago WHERE id = xId;
        UPDATE contratos SET remuneracion = xRemuneracion WHERE id = xId;
        UPDATE contratos SET lugares_id = xLugares_id WHERE id = xId;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20026, 'Error al actualizar el contrato');
    END up_contrato;
END PC_contratos;
/
CREATE OR REPLACE PACKAGE BODY PC_clientes IS
    PROCEDURE ad_cliente (xId IN NUMBER, xNombre IN VARCHAR2, xCorreo IN VARCHAR2,
        xTelefono IN VARCHAR2, xAbogados_nuip IN VARCHAR2)
    IS
    BEGIN
        INSERT INTO clientes (id, nombre, correo, telefono, abogados_nuip)
            VALUES (xId, xNombre, xCorreo, xTelefono, xAbogados_nuip);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20027, 'Error al insertar el cliente');
    END ad_cliente;
    
    PROCEDURE up_cliente (xId IN NUMBER, xCorreo IN VARCHAR2, xTelefono IN VARCHAR2,
        xAbogados_nuip IN VARCHAR2)
    IS
    BEGIN
        UPDATE clientes SET correo = xCorreo WHERE id = xId;
        UPDATE clientes SET telefono = xTelefono WHERE id = xId;
        UPDATE clientes SET abogados_nuip = xAbogados_nuip WHERE id = xId;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20028, 'Error al actualizar el cliente');
    END up_cliente;
    
    PROCEDURE de_cliente (xId IN NUMBER)
    IS
    BEGIN
        DELETE FROM clientes WHERE (id = xId);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20029, 'Error al eliminar el cliente');
    END de_cliente;
    
    PROCEDURE ad_personaNatural (xNuip IN VARCHAR2, xFecha_nacimiento IN DATE, xClientes_id IN NUMBER)
    IS
    BEGIN
        INSERT INTO personasNaturales (nuip, fecha_nacimiento, clientes_id)
            VALUES (xNuip, xFecha_nacimiento, xClientes_id);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20030, 'Error al insertar la persona natural');
    END ad_personaNatural;
    
    PROCEDURE ad_personaJuridica (xNit IN VARCHAR2, xRazon_social IN VARCHAR2, xClientes_id IN NUMBER)
    IS
    BEGIN
        INSERT INTO personasJuridicas (nit, razon_social, clientes_id)
            VALUES (xNit, xRazon_social, xClientes_id);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20031, 'Error al insertar la persona juridica');
    END ad_personaJuridica;
    
    PROCEDURE up_personaJuridica (xNit IN VARCHAR2, xRazon_social IN VARCHAR2)
    IS
    BEGIN
        UPDATE personasJuridicas SET razon_social = xRazon_social WHERE nit = xNit;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20032, 'Error al actualizar la persona juridica');
    END up_personaJuridica;
END PC_clientes;
/
CREATE OR REPLACE PACKAGE BODY PC_solicitudes IS
    PROCEDURE ad_solicitud (xId IN NUMBER, xDescripcion IN VARCHAR2, xFecha_envio IN DATE,
        xClientes_id IN NUMBER, xAbogados_nuip IN VARCHAR2)
    IS
    BEGIN
        INSERT INTO solicitudes (id, descripcion, fecha_envio, clientes_id, abogados_nuip)
            VALUES (xId, xDescripcion, xFecha_envio, xClientes_id, xAbogados_nuip);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20033, 'Error al insertar la solicitud');
    END ad_solicitud;
    
    PROCEDURE up_solicitud (xId IN NUMBER, xDescripcion IN VARCHAR2, xAbogados_nuip IN VARCHAR2)
    IS
    BEGIN
        UPDATE solicitudes SET descripcion = xDescripcion WHERE id = xId;
        UPDATE solicitudes SET abogados_nuip = xAbogados_nuip WHERE id = xId;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20028, 'Error al actualizar la solicitud');
    END up_solicitud;
    
    PROCEDURE de_solicitud (xId IN NUMBER)
    IS
    BEGIN
        DELETE FROM solicitudes WHERE (id = xId);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                RAISE_APPLICATION_ERROR(-20034, 'Error al eliminar la solicitud');
    END de_solicitud;
END PC_solicitudes;