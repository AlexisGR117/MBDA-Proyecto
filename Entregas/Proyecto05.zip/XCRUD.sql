DROP PACKAGE PC_abogados;
DROP PACKAGE PC_asesorias;
DROP PACKAGE PC_lugares;
DROP PACKAGE PC_areas;
DROP PACKAGE PC_firmas;
DROP PACKAGE PC_contratos;
DROP PACKAGE PC_clientes;
DROP PACKAGE PC_solicitudes;