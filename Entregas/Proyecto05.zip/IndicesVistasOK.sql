-- Consultar los abogados especializados en Derecho Familiar o Derecho Civil
SELECT Area, nuip, Abogado, a�os_experiencia,
       tarifa_minima, calificacion_promedio
    FROM VAbogado
    WHERE Area IN ('&area1', '&area2');
-- Consultar las calificaciones del abogado con nuip 4242574215
SELECT NombreCliente, fecha, comentario, valoracion
    FROM VCalifiaciones
    WHERE nuip = '&NUIP';
-- 4713971537
-- Consultar las firmas que tienen alguna especialidad del abogado con nuip 7370761983
SELECT Area, NIT, Firma, departamento, municipio, direccion
    FROM VFirma
    WHERE nuip = '&NUIP';
-- 1041968914

-- Consultar los hechos con sus respectivas pruebas de una demanda
SELECT Hecho, Fecha, Descripcion_Hecho, Prueba, tipo, Descripcion_prueba
    FROM VHechos
    WHERE demanda = '&Id';
-- 56
-- Consultar informacion relacionada a una audiencia
SELECT Audiencia, fecha, Juzgado, departamento, municipio, direccion
FROM VAudiencias
    WHERE nuip = '&NUIP';
--  5118068509
-- Consultar informacion de las demandas que ha hecho un cliente
SELECT Demanda, pretencion, Fecha_Demanda, estado, resultado, fallo, Fecha_sentencia, nuip, nombre
    FROM VDemandas
    WHERE clientes_id = '&Id';
-- 55