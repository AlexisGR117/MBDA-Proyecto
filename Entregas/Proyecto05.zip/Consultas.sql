-- Consultar los abogados especializados en Derecho Familiar o Derecho Civil
SELECT areas.nombre AS Area, nuip, abogados.nombre AS Abogado, a�os_experiencia,
           tarifa_minima, calificacion_promedio
        FROM abogados JOIN espAbog ON (nuip = abogados_nuip)
            JOIN areas ON (areas_id = areas.id)
            JOIN perfiles ON (perfiles.abogados_nuip = abogados.nuip)
        WHERE areas.nombre IN ('&area1', '&area2')
        ORDER BY a�os_experiencia DESC;
-- Consultar las calificaciones del abogado con nuip 4242574215
SELECT nuip, clientes.nombre as NombreCliente, fecha, comentario, valoracion
        FROM abogados JOIN perfiles ON (nuip = abogados_nuip)
            JOIN calificaciones ON (perfiles_id = perfiles.id) JOIN clientes ON (clientes_id =  clientes.id)
        WHERE nuip = '&NUIP'
        ORDER BY valoracion;
-- 4713971537
-- Consultar las firmas que tienen alguna especialidad del abogado con nuip 7370761983
SELECT nuip, areas.nombre AS Area, firmas.nit AS NIT, firmas.nombre AS Firma, departamento, municipio, direccion
    FROM abogados JOIN espAbog ON (nuip = abogados_nuip)
        JOIN espFirmas ON (espFirmas.areas_id = espAbog.areas_id)
        JOIN areas ON (espAbog.areas_id = areas.id)
        JOIN firmas ON (espFirmas.firmas_nit = firmas.nit)
        JOIN lugares ON (lugares.id = firmas.lugares_id)
    WHERE nuip = '&NUIP';
-- 1041968914

-- Consultar los hechos con sus respectivas pruebas de una demanda
SELECT hechos.id AS Hecho, hechos.fecha AS Fecha, hechos.descripcion AS Descripcion_Hecho,
    pruebas.id AS Prueba, tipo, pruebas.descripcion AS Descripcion_prueba
    FROM demandas JOIN hechos ON (demandas.id = demandas_id) 
                  LEFT JOIN pruebas ON (hechos.id = hechos_id)
    WHERE demandas.id = '&Id'
    ORDER BY Fecha DESC;
-- 56
-- Consultar informacion relacionada a las audiencias de un juez
SELECT audiencias.id AS Audiencia, fecha, juzgados.nombre AS Juzgado,
    departamento, municipio, direccion
FROM audiencias JOIN jueces ON (jueces_nuip = nuip)
                JOIN juzgados ON (juzgados_id = juzgados.id)
                JOIN lugares ON (lugares_id = lugares.id)
    WHERE jueces.nuip = '&NUIP'
    ORDER BY fecha DESC;
--  5118068509
-- Consultar informacion de las demandas que ha hecho un cliente
SELECT demandas.id, pretencion, demandas.fecha, estado, resultado, fallo, sentencias.fecha, nuip, nombre
    FROM demandas JOIN casos ON (demandas_id = demandas.id)
                  LEFT JOIN sentencias ON (casos.id = casos_id)
                  LEFT JOIN jueces ON (jueces.nuip = jueces_nuip)
    WHERE clientes_id = '&Id'
    ORDER BY demandas.fecha;
-- 55
