DROP INDEX IFirmas;
DROP INDEX IAbogados;
DROP INDEX IPerfiles1;
DROP INDEX IPerfiles2;
DROP INDEX IPerfiles3;
DROP INDEX ISolicitudes;
DROP INDEX IContratos;
DROP VIEW VAbogado;
DROP VIEW VCalificaciones;
DROP VIEW VFirma;

DROP INDEX ILugares1;
DROP INDEX ILugares2;   
    
DROP INDEX IDemandas1;
DROP INDEX IDemandas2;
DROP INDEX IHechos1;
DROP INDEX IHechos2;
DROP INDEX IPruebas;
DROP INDEX IAudiencias;
DROP INDEX ICasos;
DROP INDEX ISentencias;
DROP VIEW VAudiencias;
DROP VIEW VHechos;
DROP VIEW VDemandas;