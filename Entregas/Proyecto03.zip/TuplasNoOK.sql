INSERT INTO tarjetasProfesionales
    VALUES ('317973', '26/12/1985', '26/06/2010', 'University of Pisa',
            'Consejo seis', '8437980011');

INSERT INTO estudios (titulo, universidad, fecha_inicio, fecha_final, perfiles_id)
    VALUES ('Environmental Specialist', 'Universidade Fernando Pessoa',
            '13/09/2020', '11/03/2019', 3);