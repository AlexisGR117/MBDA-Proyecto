INSERT INTO tarjetasProfesionales
    VALUES ('317965', '26/12/2010', '26/06/2005', 'University of Pisa',
            'Consejo siete', '8437980011');

INSERT INTO estudios (titulo, universidad, fecha_inicio, fecha_final, perfiles_id)
    VALUES ('Environmental Specialist', 'Universidade Fernando Pessoa',
            '13/09/2014', '11/03/2019', 2);