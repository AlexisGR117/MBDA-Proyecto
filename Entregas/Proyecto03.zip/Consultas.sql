-- Consultar los abogados especializados en Derecho Familiar o Derecho Civil
SELECT areas.nombre AS Area, nuip, abogados.nombre AS Abogado, a�os_experiencia
    FROM abogados JOIN espAbog ON (nuip = abogados_nuip)
        JOIN areas ON (areas_id = areas.id)
        JOIN perfiles ON (perfiles.abogados_nuip = abogados.nuip)
    WHERE areas.nombre IN ('Derecho Familiar', 'Derecho Civil')
    ORDER BY a�os_experiencia DESC;
-- Consultar las calificaciones del abogado con nuip 4242574215
SELECT nuip, nombre, calificacion_promedio, fecha, comentario, valoracion
    FROM abogados JOIN perfiles ON (nuip = abogados_nuip)
        JOIN calificaciones ON (perfiles_id = perfiles.id)
    WHERE nuip = '4242574215'
    ORDER BY valoracion;
-- Consultar las firmas que tienen alguna especialidad del abogado con nuip 7370761983
SELECT firmas.nit, firmas.nombre AS Firma, abogados.nombre, areas.nombre AS Area
    FROM abogados JOIN espAbog ON (nuip = abogados_nuip)
        JOIN espFirmas ON (espFirmas.areas_id = espAbog.areas_id)
        JOIN areas ON (espAbog.areas_id = areas.id)
        JOIN firmas ON (espFirmas.firmas_nit = firmas.nit)
    WHERE nuip = '7370761983';

