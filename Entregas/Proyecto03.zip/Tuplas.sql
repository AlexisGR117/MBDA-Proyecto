ALTER TABLE tarjetasProfesionales ADD CONSTRAINT CK_tarjProf_fechas
    CHECK (fecha_grado < fecha_expedicion);
    
ALTER TABLE estudios ADD CONSTRAINT CK_estudios_fechas
    CHECK (fecha_inicio < fecha_final);
