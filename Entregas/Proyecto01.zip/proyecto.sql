-- Tablas

CREATE TABLE tarjetasProfesionales(
    numero                  NUMBER(5) NOT NULL,
    fecha_expedicion	    DATE NOT NULL,
    fecha_grado             DATE NOT NULL,
    universidad             VARCHAR2(30) NOT NULL,
    consejo_seccional       VARCHAR2(20) NOT NULL,
    abogados_nuip           VARCHAR2(10) NOT NULL);
CREATE TABLE abogados(
    nuip                    VARCHAR2(10) NOT NULL,
    correo	                VARCHAR2(40) NOT NULL,
    telefono                VARCHAR2(10) NOT NULL,
    nombre                  VARCHAR2(40) NOT NULL,
    lugares_id              NUMBER(5) NOT NULL,
    firmas_id               NUMBER(5) NOT NULL,
    fecha_de_nacimiento     DATE NOT NULL);
CREATE TABLE clientes(
    id                      NUMBER(5) NOT NULL,
    nombre                  VARCHAR2(40) NOT NULL,
    correo	                VARCHAR2(40) NOT NULL,
    telefono                VARCHAR2(10) NOT NULL,
    abogados_nuip           VARCHAR2(10) NOT NULL);
CREATE TABLE areas(
    id                      NUMBER(5) NOT NULL,
    nombre	                VARCHAR(20) NOT NULL,
    descripcion             VARCHAR2(70) NOT NULL);
CREATE TABLE firmas(
    id                      NUMBER(5) NOT NULL,
    nombre	                VARCHAR2(50) NOT NULL,
    telefono                VARCHAR2(10) NOT NULL,
    correo                  VARCHAR2(40) NOT NULL,
    lugares_id              NUMBER(5) NOT NULL);
CREATE TABLE asesorias(
    id                      NUMBER(5) NOT NULL,
    descripcion             VARCHAR2(70) NOT NULL,
    fecha                   DATE NOT NULL, 
    duracion                NUMBER(3) NOT NULL,
    precio                  NUMBER(10) NOT NULL,
    abogados_nuip           VARCHAR2(10) NOT NULL,
    clientes_id             NUMBER(5) NOT NULL);
CREATE TABLE estudios(
    id                      NUMBER(5) NOT NULL,
    titulo	                VARCHAR2(30) NOT NULL,
    universidad             VARCHAR2(30) NOT NULL,
    fecha_inicio            DATE NOT NULL,
    fecha_final             NUMBER(5) NOT NULL,
    perfiles_id             NUMBER(5) NOT NULL);
CREATE TABLE solicitudes(
    id                      NUMBER(5) NOT NULL,
    descripcion             VARCHAR2(70) NOT NULL,
    fecha_envio             DATE NOT NULL,
    clientes_id             NUMBER(5) NOT NULL,
    abogados_nuip           VARCHAR2(10) NOT NULL);
CREATE TABLE lugares(
    id                      NUMBER(5) NOT NULL,
    departamento            VARCHAR2(20) NOT NULL,
    municipio               VARCHAR2(20) NOT NULL,
    direccion               VARCHAR2(30));
CREATE TABLE perfiles(
    id                      NUMBER(5) NOT NULL,
    descripcion             VARCHAR2(70) NOT NULL,
    a�os_experiencia        NUMBER(2) NOT NULL,  
    tarifa_minima           NUMBER(10) NOT NULL,
    calificacion_promedio   NUMBER(2) NOT NULL,
    abogados_nuip           VARCHAR2(10) NOT NULL);
CREATE TABLE calificaciones(
    id                      NUMBER(5) NOT NULL,
    comentario	            VARCHAR2(70),
    valoracion              NUMBER(2) NOT NULL,
    clientes_id             NUMBER(5) NOT NULL);
CREATE TABLE contratos(
    id                      NUMBER(5) NOT NULL,
    fecha_firma	            DATE NOT NULL,
    descripcion             VARCHAR2(70) NOT NULL,
    forma_pago              VARCHAR2(20) NOT NULL,
    remuneraciom            NUMBER(10),
    clientes_id             NUMBER(5) NOT NULL,
    abogados_nuip           VARCHAR2(10) NOT NULL,
    lugares_id              NUMBER(5) NOT NULL);
CREATE TABLE espAbog(
    abogados_nuip           VARCHAR2(10) NOT NULL,
    areas_id	            NUMBER(5) NOT NULL);
CREATE TABLE espFirmas(
    firmas_id               NUMBER(5) NOT NULL,
    areas_id	            NUMBER(5) NOT NULL);
CREATE TABLE personasJuridicas(
    nit                     NUMBER(11) NOT NULL,
    razon_social            VARCHAR2(70) NOT NULL,
    clientes_id             NUMBER(5) NOT NULL);
CREATE TABLE personasNaturales(
    nuip                    NUMBER(10) NOT NULL,
    fecha_nacimiento        DATE NOT NULL,
    clientes_id             NUMBER(5) NOT NULL);
CREATE TABLE demandas(
    id                      NUMBER(5) NOT NULL,
    demandado               NUMBER(5) NOT NULL,
    pretencion              VARCHAR2(70) NOT NULL,
    cuantia                 NUMBER(10),
    fecha                   DATE NOT NULL,
    clientes_id             NUMBER(5) NOT NULL,
    juzgados_id             NUMBER(5) NOT NULL,
    casos_id                NUMBER(5) NOT NULL);
CREATE TABLE hechos(
    id                      NUMBER(5) NOT NULL,
    lugares_id	            NUMBER(5) NOT NULL,
    demandas_id	            NUMBER(5) NOT NULL,
    fecha                   DATE NOT NULL,
    descripcion             VARCHAR2(70) NOT NULL);
CREATE TABLE juzgados(
    id                      NUMBER(5) NOT NULL,
    nombre	                VARCHAR2(30) NOT NULL,
    tipo                    VARCHAR2(20) NOT NULL,
    correo                  VARCHAR2(40) NOT NULL,
    telefono                VARCHAR2(10) NOT NULL,
    lugares_id              NUMBER(5) NOT NULL);
CREATE TABLE casos(
    id                      NUMBER(5) NOT NULL,
    estado	                VARCHAR2(10) NOT NULL,
    resultado               VARCHAR2(10));
CREATE TABLE sentencias(
    numero                  NUMBER(5) NOT NULL,
    fecha	                NUMBER(5) NOT NULL,
    fallo                   VARCHAR2(70) NOT NULL,
    casos_id                NUMBER(5) NOT NULL,
    jueces_nuip             VARCHAR2(10) NOT NULL);
CREATE TABLE audiencias(
    id                      NUMBER(5) NOT NULL,
    fecha	                DATE NOT NULL,
    fallo                   VARCHAR2(70) NOT NULL,
    jueces_nuip             VARCHAR2(10) NOT NULL,
    juzgados_id             NUMBER(5) NOT NULL);
CREATE TABLE revisiones(
    perfiles_id             NUMBER(5) NOT NULL,
    clientes_id             NUMBER(5) NOT NULL);
CREATE TABLE perfCal(
    perfiles_id            NUMBER(5) NOT NULL,
    calificaciones_id      NUMBER(5) NOT NULL);
CREATE TABLE pruebas(
    id                      NUMBER(5) NOT NULL,
    hechos_id	            NUMBER(5) NOT NULL,
    tipo                    VARCHAR2(20) NOT NULL,
    descripcion             VARCHAR2(70),
    medio                   VARCHAR2(20) NOT NULL);
CREATE TABLE jueces(
    nuip                    VARCHAR2(10) NOT NULL,
    nombre                  VARCHAR(40) NOT NULL,
    correo                  VARCHAR2(40),
    telefono                VARCHAR2(10));
CREATE TABLE fundamentosDerechos(
    id                      NUMBER(5) NOT NULL,
    norma_juridica          VARCHAR(20) NOT NULL,
    descripcion             VARCHAR(70) NOT NULL);
CREATE TABLE demFun(
    demandas_id             NUMBER(5) NOT NULL,
    fundamentosDerechos_id  NUMBER(5) NOT NULL);

-- Primarias

ALTER TABLE lugares ADD CONSTRAINT PK_lugares
    PRIMARY KEY (id);   
ALTER TABLE abogados ADD CONSTRAINT PK_abogados
    PRIMARY KEY (nuip);
ALTER TABLE clientes ADD CONSTRAINT PK_clientes
    PRIMARY KEY (id);
ALTER TABLE revisiones ADD CONSTRAINT PK_revisiones
    PRIMARY KEY (perfiles_id, clientes_id);
ALTER TABLE tarjetasProfesionales ADD CONSTRAINT PK_tarjetasProfesionales
    PRIMARY KEY (numero);
ALTER TABLE areas ADD CONSTRAINT PK_areas
    PRIMARY KEY (id);
ALTER TABLE firmas ADD CONSTRAINT PK_firmas
    PRIMARY KEY (id);
ALTER TABLE asesorias ADD CONSTRAINT PK_asesorias
    PRIMARY KEY (id);
ALTER TABLE estudios ADD CONSTRAINT PK_estudios
    PRIMARY KEY (id);
ALTER TABLE solicitudes ADD CONSTRAINT PK_solicitudes
    PRIMARY KEY (id);
ALTER TABLE perfiles ADD CONSTRAINT PK_perfiles
    PRIMARY KEY (id);
ALTER TABLE calificaciones ADD CONSTRAINT PK_calificaciones
    PRIMARY KEY (id);
ALTER TABLE contratos ADD CONSTRAINT PK_contratos
    PRIMARY KEY (id);
ALTER TABLE espAbog ADD CONSTRAINT PK_espAbog
    PRIMARY KEY (abogados_nuip, areas_id);
ALTER TABLE espFirmas ADD CONSTRAINT PK_espFirmas
    PRIMARY KEY (firmas_id, areas_id);
ALTER TABLE personasJuridicas ADD CONSTRAINT PK_personasJuridicas
    PRIMARY KEY (nit);
ALTER TABLE personasNaturales ADD CONSTRAINT PK_personasNaturales
    PRIMARY KEY (nuip);
ALTER TABLE demandas ADD CONSTRAINT PK_demandas
    PRIMARY KEY (id);
ALTER TABLE hechos ADD CONSTRAINT PK_hechos
    PRIMARY KEY (id);
ALTER TABLE juzgados ADD CONSTRAINT PK_juzgados
    PRIMARY KEY (id);
ALTER TABLE casos ADD CONSTRAINT PK_casos
    PRIMARY KEY (id);
ALTER TABLE sentencias ADD CONSTRAINT PK_sentencias
    PRIMARY KEY (numero);
ALTER TABLE audiencias ADD CONSTRAINT PK_audiencias
    PRIMARY KEY (id);
ALTER TABLE perfCal ADD CONSTRAINT PK_perfCal
    PRIMARY KEY (perfiles_id, calificaciones_id);
ALTER TABLE pruebas ADD CONSTRAINT PK_pruebas
    PRIMARY KEY (id);
ALTER TABLE jueces ADD CONSTRAINT PK_jueces
    PRIMARY KEY (nuip);
ALTER TABLE fundamentosDerechos ADD CONSTRAINT PK_fundamentosDerechos
    PRIMARY KEY (id);
ALTER TABLE demFun ADD CONSTRAINT PK_demFun
    PRIMARY KEY (demandas_id, fundamentosDerechos_id);

-- Unicas

ALTER TABLE firmas ADD CONSTRAINT UK_firmas_nombre
    UNIQUE (nombre);
ALTER TABLE firmas ADD CONSTRAINT UK_firmas_telefono
    UNIQUE (telefono);
ALTER TABLE firmas ADD CONSTRAINT UK_firmas_correo
    UNIQUE (correo);
ALTER TABLE areas ADD CONSTRAINT UK_areas_nombre
    UNIQUE (nombre);
ALTER TABLE abogados ADD CONSTRAINT UK_abogados_telefono
    UNIQUE (telefono);
ALTER TABLE abogados ADD CONSTRAINT UK_abogados_correo
    UNIQUE (correo);    
ALTER TABLE perfiles ADD CONSTRAINT UK_perfil_descripcion
    UNIQUE (descripcion);    
ALTER TABLE clientes ADD CONSTRAINT UK_clientes_telefono
    UNIQUE (telefono);
ALTER TABLE clientes ADD CONSTRAINT UK_clientes_correo
    UNIQUE (correo);
ALTER TABLE juzgados ADD CONSTRAINT UK_juzgados_correo
    UNIQUE (correo);
ALTER TABLE juzgados ADD CONSTRAINT UK_juzgados_nombre
    UNIQUE (nombre);
ALTER TABLE juzgados ADD CONSTRAINT UK_juzgados_telefono
    UNIQUE (telefono);
ALTER TABLE jueces ADD CONSTRAINT UK_jueces_telefono
    UNIQUE (telefono);
ALTER TABLE jueces ADD CONSTRAINT UK_jueces_correo
    UNIQUE (correo);        
ALTER TABLE fundamentosDerechos ADD CONSTRAINT UK_funDerechos_norma_juridica
    UNIQUE (norma_juridica);
ALTER TABLE calificaciones ADD CONSTRAINT UK_calificaciones_comentario
    UNIQUE (comentario);     

-- Foraneas
    
 
ALTER TABLE firmas ADD CONSTRAINT FK_firmas_lugares
    FOREIGN KEY (lugares_id) REFERENCES lugares(id);
ALTER TABLE abogados ADD CONSTRAINT FK_abogados_lugares
    FOREIGN KEY (lugares_id) REFERENCES lugares(id);
ALTER TABLE abogados ADD CONSTRAINT FK_abogados_firmas
    FOREIGN KEY (firmas_id) REFERENCES firmas(id);
ALTER TABLE espFirmas ADD CONSTRAINT FK_espFirmas_firmas
    FOREIGN KEY (firmas_id) REFERENCES firmas(id);
ALTER TABLE espFirmas ADD CONSTRAINT FK_espFirmas_areas
    FOREIGN KEY (areas_id) REFERENCES areas(id);
ALTER TABLE espAbog ADD CONSTRAINT FK_espAbog_abogados
    FOREIGN KEY (abogados_nuip) REFERENCES abogados(nuip);
ALTER TABLE espAbog ADD CONSTRAINT FK_espAbog_areas
    FOREIGN KEY (areas_id) REFERENCES areas(id);
ALTER TABLE tarjetasProfesionales ADD CONSTRAINT FK_tarProfesionales_abogados
    FOREIGN KEY (abogados_nuip) REFERENCES abogados(nuip);    
ALTER TABLE perfiles ADD CONSTRAINT FK_perfiles_abogados
    FOREIGN KEY (abogados_nuip) REFERENCES abogados(nuip); 
ALTER TABLE estudios ADD CONSTRAINT FK_estudios_perfiles
    FOREIGN KEY (perfiles_id) REFERENCES perfiles(id);
ALTER TABLE clientes ADD CONSTRAINT FK_clientes_abogados
    FOREIGN KEY (abogados_nuip) REFERENCES abogados(nuip);
ALTER TABLE asesorias ADD CONSTRAINT FK_asesorias_abogados
    FOREIGN KEY (abogados_nuip) REFERENCES abogados(nuip);
ALTER TABLE asesorias ADD CONSTRAINT FK_asesorias_clientes
    FOREIGN KEY (clientes_id) REFERENCES clientes(id);
ALTER TABLE solicitudes ADD CONSTRAINT FK_solicitudes_abogados
    FOREIGN KEY (abogados_nuip) REFERENCES abogados(nuip);
ALTER TABLE solicitudes ADD CONSTRAINT FK_solicitudes_clientes
    FOREIGN KEY (clientes_id) REFERENCES clientes(id);
ALTER TABLE revisiones ADD CONSTRAINT FK_revisiones_clientes
    FOREIGN KEY (clientes_id) REFERENCES clientes(id);
ALTER TABLE revisiones ADD CONSTRAINT FK_revisiones_perfiles
    FOREIGN KEY (perfiles_id) REFERENCES perfiles(id);
ALTER TABLE personasNaturales ADD CONSTRAINT FK_personasNaturales_clientes
    FOREIGN KEY (clientes_id) REFERENCES clientes(id);
ALTER TABLE personasJuridicas ADD CONSTRAINT FK_personasJuridicas_clientes
    FOREIGN KEY (clientes_id) REFERENCES clientes(id);
ALTER TABLE calificaciones ADD CONSTRAINT FK_calificaciones_clientes
    FOREIGN KEY (clientes_id) REFERENCES clientes(id);
ALTER TABLE perfCal ADD CONSTRAINT FK_perfCal_perfiles
    FOREIGN KEY (perfiles_id) REFERENCES perfiles(id);
ALTER TABLE perfCal ADD CONSTRAINT FK_perfCal_calificaciones
    FOREIGN KEY (calificaciones_id) REFERENCES calificaciones(id);
ALTER TABLE contratos ADD CONSTRAINT FK_contratos_clientes
    FOREIGN KEY (clientes_id) REFERENCES clientes(id);
ALTER TABLE contratos ADD CONSTRAINT FK_contratos_abogados
    FOREIGN KEY (abogados_nuip) REFERENCES abogados(nuip);
ALTER TABLE contratos ADD CONSTRAINT FK_contratos_lugares
    FOREIGN KEY (lugares_id) REFERENCES lugares(id);
ALTER TABLE juzgados ADD CONSTRAINT FK_juzgados_lugares
    FOREIGN KEY (lugares_id) REFERENCES lugares(id);
ALTER TABLE demandas ADD CONSTRAINT FK_demandas_clientes
    FOREIGN KEY (clientes_id) REFERENCES clientes(id);
ALTER TABLE demandas ADD CONSTRAINT FK_demandas_juzgados
    FOREIGN KEY (juzgados_id) REFERENCES juzgados(id);
ALTER TABLE demandas ADD CONSTRAINT FK_demandas_casos
    FOREIGN KEY (casos_id) REFERENCES casos(id); 
ALTER TABLE hechos ADD CONSTRAINT FK_hechos_lugares
    FOREIGN KEY (lugares_id) REFERENCES lugares(id);
ALTER TABLE hechos ADD CONSTRAINT FK_hechos_demandas
    FOREIGN KEY (demandas_id) REFERENCES demandas(id);
ALTER TABLE pruebas ADD CONSTRAINT FK_pruebas_hechos
    FOREIGN KEY (hechos_id) REFERENCES hechos(id); 
ALTER TABLE sentencias ADD CONSTRAINT FK_sentencias_casos
    FOREIGN KEY (casos_id) REFERENCES casos(id);
ALTER TABLE sentencias ADD CONSTRAINT FK_sentencias_jueces
    FOREIGN KEY (jueces_nuip) REFERENCES jueces(nuip);
ALTER TABLE demFun ADD CONSTRAINT FK_demFun_demandas
    FOREIGN KEY (demandas_id) REFERENCES demandas(id);
ALTER TABLE demFun ADD CONSTRAINT FK_demFun_fundamentosDerechos
    FOREIGN KEY (fundamentosDerechos_id) REFERENCES fundamentosDerechos(id);
ALTER TABLE audiencias ADD CONSTRAINT FK_audiencias_jueces
    FOREIGN KEY (jueces_nuip) REFERENCES jueces(nuip);
ALTER TABLE audiencias ADD CONSTRAINT FK_audicencas_juzgados
    FOREIGN KEY (juzgados_id) REFERENCES juzgados(id);
    
-- XPoblar

DELETE FROM demFun;
DELETE FROM pruebas;
DELETE FROM sentencias;
DELETE FROM perfCal;
DELETE FROM revisiones;
DELETE FROM asesorias;
DELETE FROM estudios;
DELETE FROM solicitudes;
DELETE FROM audiencias;
DELETE FROM contratos;
DELETE FROM personasNaturales;
DELETE FROM personasJuridicas;
DELETE FROM tarjetasProfesionales;
DELETE FROM espAbog;
DELETE FROM espFirmas;
DELETE FROM perfiles;
DELETE FROM calificaciones;
DELETE FROM hechos;
DELETE FROM demandas;
DELETE FROM fundamentosDerechos;
DELETE FROM jueces;
DELETE FROM casos;
DELETE FROM juzgados;
DELETE FROM areas;
DELETE FROM clientes;
DELETE FROM abogados;
DELETE FROM firmas;
DELETE FROM lugares;

-- XTablas

DROP TABLE demFun;
DROP TABLE pruebas;
DROP TABLE sentencias;
DROP TABLE perfCal;
DROP TABLE revisiones;
DROP TABLE asesorias;
DROP TABLE estudios;
DROP TABLE solicitudes;
DROP TABLE audiencias;
DROP TABLE contratos;
DROP TABLE personasNaturales;
DROP TABLE personasJuridicas;
DROP TABLE tarjetasProfesionales;
DROP TABLE espAbog;
DROP TABLE espFirmas;
DROP TABLE perfiles;
DROP TABLE calificaciones;
DROP TABLE hechos;
DROP TABLE demandas;
DROP TABLE fundamentosDerechos;
DROP TABLE jueces;
DROP TABLE casos;
DROP TABLE juzgados;
DROP TABLE areas;
DROP TABLE clientes;
DROP TABLE abogados;
DROP TABLE firmas;
DROP TABLE lugares;
